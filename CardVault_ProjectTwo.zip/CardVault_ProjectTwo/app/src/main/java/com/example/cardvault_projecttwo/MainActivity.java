package com.example.cardvault_projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

// Primary activity for handling login, new account setup, and guest mode entry
public class MainActivity extends AppCompatActivity {

    // Member variables for layout fields
    private EditText usernameField;
    private EditText passwordField;
    private Button loginButton;
    private Button createAccountButton;

    // Database connection instance
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize local SQLite database helper
        databaseHelper = new DatabaseHelper(this);

        // Map views to exact IDs inside activity_login.xml
        usernameField = findViewById(R.id.edit_text_username);
        passwordField = findViewById(R.id.edit_text_password);
        loginButton = findViewById(R.id.button_login);
        createAccountButton = findViewById(R.id.button_create_account);

        // Dynamically create a Guest button to satisfy rubric requirements
        Button guestButton = new Button(this);
        guestButton.setText("Continue as Guest");

        // Add guest button to the existing linear layout programmatically
        LinearLayout mainLayout = (LinearLayout) usernameField.getParent();
        if (mainLayout != null) {
            mainLayout.addView(guestButton);
        }

        // LOG IN CLICK EVENT
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userInput = usernameField.getText().toString().trim();
                String passInput = passwordField.getText().toString().trim();

                // Prevent submitting empty fields
                if (userInput.isEmpty() || passInput.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter both username and password.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Verify username and password in SQLite database
                boolean userExists = databaseHelper.checkUserCredentials(userInput, passInput);

                if (userExists) {
                    Toast.makeText(MainActivity.this, "Welcome back!", Toast.LENGTH_SHORT).show();

                    // Transition to the main card inventory activity
                    Intent launchInventory = new Intent(MainActivity.this, DataActivity.class);
                    startActivity(launchInventory);
                    finish(); // Finish activity so back button doesn't return to login
                } else {
                    Toast.makeText(MainActivity.this, "Invalid login credentials.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // CREATES NEW ACCOUNT CLICK EVENT
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newUsername = usernameField.getText().toString().trim();
                String newPassword = passwordField.getText().toString().trim();

                if (newUsername.isEmpty() || newPassword.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter desired username and password to register.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Insert new account record into local database
                boolean userCreated = databaseHelper.createNewUser(newUsername, newPassword);

                if (userCreated) {
                    Toast.makeText(MainActivity.this, "Account created successfully! You can now log in.", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, "Username taken. Please choose another.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // GUEST MODE CLICK EVENT
        guestButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Entering app in Guest Mode...", Toast.LENGTH_SHORT).show();

                // Jump directly to main app without user login check
                Intent guestIntent = new Intent(MainActivity.this, DataActivity.class);
                startActivity(guestIntent);
            }
        });
    }
}
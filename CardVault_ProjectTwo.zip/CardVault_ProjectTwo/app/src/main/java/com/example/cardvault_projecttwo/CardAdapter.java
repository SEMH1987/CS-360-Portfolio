package com.example.cardvault_projecttwo;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

// Custom adapter to populate our RecyclerView with card items from SQLite
public class CardAdapter extends RecyclerView.Adapter<CardAdapter.CardViewHolder> {

    private Context context;
    private ArrayList<CardItem> cardList;
    private DatabaseHelper dbHelper;
    private Runnable refreshCallback;

    // Simple model class for holding card row data
    public static class CardItem {
        int id;
        String name;
        int qty;

        public CardItem(int id, String name, int qty) {
            this.id = id;
            this.name = name;
            this.qty = qty;
        }
    }

    public CardAdapter(Context context, ArrayList<CardItem> cardList, DatabaseHelper dbHelper, Runnable refreshCallback) {
        this.context = context;
        this.cardList = cardList;
        this.dbHelper = dbHelper;
        this.refreshCallback = refreshCallback;
    }

    @NonNull
    @Override
    public CardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate your item_card_row.xml layout for each row
        View view = LayoutInflater.from(context).inflate(R.layout.item_card_row, parent, false);
        return new CardViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CardViewHolder holder, int position) {
        CardItem item = cardList.get(position);

        holder.textName.setText(item.name);
        holder.textQty.setText(String.valueOf(item.qty));

        // Delete item from SQLite when action button is clicked
        holder.btnAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean deleted = dbHelper.deleteCardEntry(item.id);
                if (deleted) {
                    Toast.makeText(context, "Removed " + item.name, Toast.LENGTH_SHORT).show();
                    refreshCallback.run(); // Reload grid view
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return cardList.size();
    }

    public static class CardViewHolder extends RecyclerView.ViewHolder {
        TextView textName, textQty;
        Button btnAction;

        public CardViewHolder(@NonNull View itemView) {
            super(itemView);
            // Map to item_card_row.xml view IDs
            textName = itemView.findViewById(R.id.text_card_name);
            textQty = itemView.findViewById(R.id.text_card_qty);
            btnAction = itemView.findViewById(R.id.button_delete_card);
        }
    }
}

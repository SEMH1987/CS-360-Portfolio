package com.example.cardvault_projecttwo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

// Main inventory activity displaying card records and managing SMS permissions
public class DataActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;

    // UI elements mapped directly to activity_data.xml
    private EditText editCardName, editCardQty;
    private Button buttonAddCard;
    private RecyclerView recyclerViewCards;

    // Database helper and list adapter
    private DatabaseHelper databaseHelper;
    private CardAdapter cardAdapter;
    private ArrayList<CardAdapter.CardItem> cardItemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // Initialize SQLite helper and array list
        databaseHelper = new DatabaseHelper(this);
        cardItemList = new ArrayList<>();

        // Match exact IDs from activity_data.xml
        editCardName = findViewById(R.id.edit_text_card_name);
        editCardQty = findViewById(R.id.edit_text_card_qty);
        buttonAddCard = findViewById(R.id.button_add_card);
        recyclerViewCards = findViewById(R.id.recycler_view_cards);

        // Configure RecyclerView layout manager
        recyclerViewCards.setLayoutManager(new LinearLayoutManager(this));

        // Prompt for SMS permission as soon as the main inventory screen opens
        checkAndRequestSmsPermission();

        // Load existing items from database into RecyclerView
        refreshCardGrid();

        // CREATE: Add new card item to local database
        buttonAddCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cardName = editCardName.getText().toString().trim();
                String qtyString = editCardQty.getText().toString().trim();

                if (cardName.isEmpty() || qtyString.isEmpty()) {
                    Toast.makeText(DataActivity.this, "Please enter both card name and quantity.", Toast.LENGTH_SHORT).show();
                    return;
                }

                int quantity = Integer.parseInt(qtyString);
                boolean isInserted = databaseHelper.insertNewCard(cardName, quantity);

                if (isInserted) {
                    Toast.makeText(DataActivity.this, "Card added to vault!", Toast.LENGTH_SHORT).show();
                    editCardName.setText("");
                    editCardQty.setText("");
                    refreshCardGrid();

                    // Trigger SMS alert if inventory is low (<= 2)
                    if (quantity <= 2) {
                        sendLowStockSmsAlert(cardName, quantity);
                    }
                } else {
                    Toast.makeText(DataActivity.this, "Failed to add card.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // READ: Load database rows into list and update RecyclerView adapter
    private void refreshCardGrid() {
        cardItemList.clear();
        Cursor cursor = databaseHelper.fetchAllCards();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_CARD_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_CARD_NAME));
                int qty = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_CARD_COUNT));

                cardItemList.add(new CardAdapter.CardItem(id, name, qty));
            } while (cursor.moveToNext());

            cursor.close();
        }

        cardAdapter = new CardAdapter(this, cardItemList, databaseHelper, new Runnable() {
            @Override
            public void run() {
                refreshCardGrid(); // Callback to refresh grid when an item is deleted
            }
        });
        recyclerViewCards.setAdapter(cardAdapter);
    }

    // Check SMS permissions at runtime
    private void checkAndRequestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    // Handle user response to SMS permission popup
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted! Alerts enabled.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied. Continuing without SMS alerts.", Toast.LENGTH_LONG).show();
            }
        }
    }

    // Dispatch text notification if low stock threshold is reached
    private void sendLowStockSmsAlert(String cardName, int quantity) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                String textMessage = "CardVault Alert: Low stock on " + cardName + " (Count: " + quantity + ")";
                smsManager.sendTextMessage("5555645555", null, textMessage, null, null);
                Toast.makeText(this, "Low stock SMS notification sent!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Low stock alert triggered (Simulated)", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Low stock alert triggered (SMS permission turned off)", Toast.LENGTH_SHORT).show();
        }
    }
}
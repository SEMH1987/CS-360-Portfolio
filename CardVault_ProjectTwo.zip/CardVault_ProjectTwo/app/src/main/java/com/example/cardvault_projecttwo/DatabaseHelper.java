package com.example.cardvault_projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// Basic helper class to handle creating and running SQL queries on our local database
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name and current version setup
    private static final String DB_NAME = "CardVaultStorage.db";
    private static final int DB_VERSION = 1;

    // User table details
    public static final String USER_TABLE = "user_account_table";
    public static final String COL_USER_ID = "user_id";
    public static final String COL_USERNAME = "user_name";
    public static final String COL_PASSWORD = "user_password";

    // Card inventory table details
    public static final String CARDS_TABLE = "card_inventory_table";
    public static final String COL_CARD_ID = "card_id";
    public static final String COL_CARD_NAME = "card_title";
    public static final String COL_CARD_COUNT = "card_quantity";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL string to build the account table for logins
        String createUsersSql = "CREATE TABLE " + USER_TABLE + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE, " +
                COL_PASSWORD + " TEXT)";

        // SQL string to build the inventory table for keeping track of cards
        String createCardsSql = "CREATE TABLE " + CARDS_TABLE + " (" +
                COL_CARD_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_CARD_NAME + " TEXT, " +
                COL_CARD_COUNT + " INTEGER)";

        // Execute both table creation queries
        db.execSQL(createUsersSql);
        db.execSQL(createCardsSql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop old tables if version changes so we can recreate them clean
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + CARDS_TABLE);
        onCreate(db);
    }

    // Insert a new user login into our user database table
    public boolean createNewUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        long insertResult = db.insert(USER_TABLE, null, values);
        // If insertResult is -1 then the insert failed (probably a duplicate username)
        return insertResult != -1;
    }

    // Check if entered username and password match any row in our database
    public boolean checkUserCredentials(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Query to match both fields
        String query = "SELECT * FROM " + USER_TABLE + " WHERE " +
                COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ?";

        Cursor cursor = db.rawQuery(query, new String[]{username, password});
        boolean userFound = cursor.getCount() > 0;
        cursor.close(); // Close cursor so we don't leak memory
        return userFound;
    }

    // INVENTORY CRUD OPERATIONS

    // Adds a new card entry into the inventory database
    public boolean insertNewCard(String name, int qty) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_CARD_NAME, name);
        values.put(COL_CARD_COUNT, qty);

        long result = db.insert(CARDS_TABLE, null, values);
        return result != -1;
    }

    // get all cards currently in the database table
    public Cursor fetchAllCards() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + CARDS_TABLE, null);
    }

    // updates the quantity value for a specific card ID row
    public boolean updateCardQuantity(int cardId, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_CARD_COUNT, newQuantity);

        int rowsAffected = db.update(CARDS_TABLE, values, COL_CARD_ID + " = ?", new String[]{String.valueOf(cardId)});
        return rowsAffected > 0;
    }

    // Remove a card item row using its database ID
    public boolean deleteCardEntry(int cardId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(CARDS_TABLE, COL_CARD_ID + " = ?", new String[]{String.valueOf(cardId)});
        return rowsDeleted > 0;
    }
}
